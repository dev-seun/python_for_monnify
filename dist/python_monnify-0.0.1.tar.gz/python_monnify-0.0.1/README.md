'This package allow you to connnect to monnify payment gateway with ease, and perform most of monnify payment solution offered'

The package support actions like transactioin checking
Creating of virtual accounts 
Updating of virtual account
Updating virtual account bvn
Initializing one time payment transaction
etc.

NOTE:
AFter initializing the onr time payment transaction
from theh response your are to follow the checkout url provided by moniify to complete that transaction



if you have any request or clearification feel free to talk to me about it.